mex SRAD_c.c
