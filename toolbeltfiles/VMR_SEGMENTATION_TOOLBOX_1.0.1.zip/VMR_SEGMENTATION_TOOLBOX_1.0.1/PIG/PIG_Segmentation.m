function [numseg vert]= PIG_Segmentation(Imagefile)

% Poisson inverse gradient (PIG) automatic initialization.

%     Reference
%     [1] Bing Li and Scott T. Acton, "Active contour external force using
%     vector field convolution for image segmentation," Image Processing,
%     IEEE Trans. on, vol. 16, pp. 2096-2106, 2007.
%     [2] Bing Li and Scott T. Acton, "Automatic Active Model
%     Initialization via Poisson Inverse Gradient," Image Processing,
%     IEEE Trans. on, vol. 17, pp. 1406-1420, 2008.
%
% (c) Copyright Bing Li 2005 - 2009.

%% Parameter settings
SAVE_SEGMENTS = 1; % set it to 1 if you want to save the segments as .mat file else 0
NUM_SEGMENTS_SEL = 1;% set it to 0 if you need to fix the number of segments for the image (num_segments)
DISPLAY_DETAILS = 0;% set it to 1 if you want to see the initial segments
DISPLAY_SEGMENTATION = 1;%set it to 0 if you do not want to display the segmentation result 
DISPLAY_ENERGYMAP = 0;% set it to 1 if you want to display the energy maps
DISCARD = 1;% set it to 0 if you do not want to discard segments with smaller area 

alpha = .5;
beta = .1;
tau = .5;
colorstring='ymcrgb';
c = 'g--';
num_segments=1; % change the number if NUM_SEGMENTS_SEL = 0;
%% Read Image
Image = imread(Imagefile); 
[x y z] = size(Image);

if z ==3
    I0 = rgb2gray(Image);
else
    I0 = Image;
end

I = I0;

%% Compute edge map and external force field
disp('Computing edge map and force field...')
f = edge(I,'canny',.2,1.5); 
omega = ~f;
K = AM_VFK(2, 64, 'power',3);
Fext = AM_VFC(f, K, 1);

method = 3;
lambda = 5:5:50;    % isovalues
E = AM_PIG(Fext, omega, double(f)); %Energy calculation

%% Number of segment selection
if NUM_SEGMENTS_SEL == 0 && num_segments==0
    error('number of segments (num_segments) need to be greater than 0')
else if NUM_SEGMENTS_SEL == 0 && num_segments~=0
        eta = num_segments;
    else if NUM_SEGMENTS_SEL == 1
            P=ceil(E);
            eta=3*((max(max(P))-min(min(P))));
        end
    end
end


[vert isoValue] = AC_isoLine(E, lambda, eta); 


%% Display initial segments
K = length(vert);
ModelNum(method) = K;
if DISPLAY_DETAILS
    figure();
    imshow(I0) 
    for k = 1:K
        h = AC_display(vert{k},'close',c);
        set(h,'LineWidth',3)
    end
    drawnow, pause(.5)
end
%This is the end of the PIG algorithm

%% The deformation of a snake begins here
area_previous = zeros(1,K);
for k = 1:K,
    area_previous(k) = polyarea(vert{k}(:,1),vert{k}(:,2));
end
area_diff = area_previous;  % compute areas for converge condition
iter = 0;
flagsConverged = zeros(1,K);

while ~all(flagsConverged)
    iter = iter+3;
    flagsConverged = abs(area_diff)<1;  % converge condition: area change less than 1
    for k = 1:K,
        if flagsConverged(k)
            continue
        end
        vert{k} = AC_deform(vert{k},alpha,beta,tau,Fext,3);
        area = polyarea(vert{k}(:,1),vert{k}(:,2));
        area_diff(k) = area - area_previous(k);
        area_previous(k) = area;
        
        if mod(iter,9)==0,
            vert{k} = AC_remesh2(vert{k},1); %Change back once Remesh is fast
        end
     
    end
    
end
vert1 =  vert;
%% Discard segments with area under a certain threshold
if DISCARD 
    % calculate area of each segments
    for ii=1:1:K
        jk(ii)=size(vert1{ii},1);
        area_of_cont(ii) = polyarea(vert1{ii}(:,1),vert1{ii}(:,2));
    end
    sum_area = sum(area_of_cont);
    [f_sort_area t_sort_area]=sort(area_of_cont,'descend');
    s1=f_sort_area(1);
    
    % keep segments which constitute 90% of the total area of all the segments 
    for kk1=2:K
        s1=s1+(f_sort_area(kk1));
        if s1>=0.90*sum_area;
            break
        end
    end
    N_t_area=t_sort_area(1:kk1);
    
    K_1=(N_t_area);
    K=size(K_1,2);
    clear vert
    
    % keep only the largers segments
    for it=1:1:K
        vert{it}=vert1{K_1(it)};
    end
end
numseg = K;
%% Display Segments
if DISPLAY_SEGMENTATION 
figure()
imshow(I0)
         for k = 1:K
             yocolor=colorstring(mod(k,6)+1);
             yocolor=strcat(yocolor,'-');
            try
                 h = AC_display(vert{k},'close',yocolor);
                 set(h,'linewidth',3)
            end
         end
         drawnow, pause(.5)
end

%% Save File
if SAVE_SEGMENTS 
    saveFileName = '\PIG_VFCsegment.mat';
    save(saveFileName,'vert','Imagefile','numseg');
end


%% Energy Map
if DISPLAY_ENERGYMAP 
            figure() % display e with isolines
             imagesc(e-max(e(:))+min(e(:))-1);
             hold on
             contour(e,lambda,'linewidth',2.5)
             hold off

             axis image, axis off
             set(gca,'clim',[min(e(:))*2-max(e(:))-1,max(e(:))])
             colormap([gray(128); jet(32) ;jet(96)]);
end