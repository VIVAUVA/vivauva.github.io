function vert = VFC_segmentation(Imagefile)

% Vector Field Convolution as external field for Active Contour

%     Reference
%     [1] Bing Li and Scott T. Acton, "Active contour external force using
%     vector field convolution for image segmentation," Image Processing,
%     IEEE Trans. on, vol. 16, pp. 2096-2106, 2007.
%
% (c) Copyright Bing Li 2005 - 2009.

%% Parameter settings
%disp('Initializing parameters ...')
SAVE_AVI = 0;           % set it to 1 if you want to save the process as .avi movie
DISPLAY_STREAMLINE = 0; % set it to 1 if you want to plot streamlines, note that it takes a while
DISPLAY_FEXTERNAL = 0; % set it to 1 if you want to display the external force field
DISPLAY_DEFORMATION = 0; %set it to 1 if you want to view the snake deformation
SAVE_SEGMENTS = 1; % set it to 1 if you want to save the segments as .mat file else 0
DISPLAY_SEGMENTATION = 1;%set it to 0 if you do not want to display the segmentation result 


mu = .2;
alpha = .5;
beta = 0.01;
tau = .5;
SNAKE_ITER = 5;
SNAKE_ITER1 = 80;
RES = .5;
c = 'g--';
%% Read image
Image = imread(Imagefile);
[x y z] = size(Image);

if z ==3
    I0 = rgb2gray(Image);
else
    I0 = Image;
end
I = I0;

%% Compute edge map and external force field
% disp('Computing edge map and force field...')
f = edge(I,'canny',.2,1.5);
omega = ~f;

K = AM_VFK(2, 32, 'power',1.8);
Fext = AM_VFC(f, K, 1);
titl = 'VFC'
%% display extrenal force field

if DISPLAY_STREAMLINE,
    disp('Displaying the external force field ...')
    figure()
    [x y] = meshgrid(.5:64,.5:64);
    vt = [x(:) y(:)];   % seeds
    VT = zeros([size(vt) 40]);
    VT(:,:,1) = vt;
    for i=1:39, % moving these seeds
        vt = AC_deform(vt,0,0,tau,Fext,1);
        VT(:,:,i+1) = vt;
    end
    
    [Ty Tx] = find(~U);  % ground truth
    hold on
    for i=1:size(vt,1),
        if min(abs(VT(i,1,end)-Tx)+abs(VT(i,2,end)-Ty))<=2,
            % converge to U-shape
            plot(squeeze(VT(i,1,:)), squeeze(VT(i,2,:)),'r','linewidth',1)
        else
            plot(squeeze(VT(i,1,:)), squeeze(VT(i,2,:)),'k','linewidth',1)
        end
    end
    hold off
    axis equal; axis 'ij';
    axis([1 64 1 64])
else if DISPLAY_FEXTERNAL,
        disp('Displaying the external force field ...')
        figure()
        AC_quiver(Fext, I);
        title(['normalized ',titl,' field']);
    end
end
% uncomment these 2 lines to save the display
%     F = getframe(gca);
%     imwrite(F.cdata,['vector_field',num2str(cs),'.bmp']);

%% Initialize the snake
disp('Initializing the snake ...')
imshow(I)
vert  = AC_initial(RES, 'open');

vert0 = vert;

%% Deformation of snake
if DISPLAY_DEFORMATION,
    imshow(I)
    AC_display(vert,'close',clr{cs});
    h=AC_display(vert,'close',c);
    set(h,'LineWidth',3)
    drawnow, pause(.5)
end

if SAVE_AVI
    mov = avifile(['example_vfc_',num2str(cs),'.avi'],'fps',4,'quality',100,'compression','None');
    frame = getframe(gca);
    mov = addframe(mov,frame);
end

disp('Deforming the snake ...')
for i=1:SNAKE_ITER1,
    vert = AC_deform(vert,alpha,beta,tau,Fext,SNAKE_ITER);
    vert = AC_remesh(vert,.5);
    
    if DISPLAY_DEFORMATION,
        if mod(i,10)==0,
            imshow(I)
            h=AC_display(vert,'close',c);
            set(h,'LineWidth',3)
            h=AC_display(vert0,'close',['r--']);
            title([titl ' iteration ' num2str(i)])
            drawnow, pause(.5)
        end
    end
    if SAVE_AVI
        frame = getframe(gca);
        mov = addframe(mov,frame);
    end
end
disp('Done!')

if SAVE_AVI
    h=close(mov);
end
%% Display final segmentation
if DISPLAY_SEGMENTATION,
    figure()
    imshow(I)
    h=AC_display(vert,'close',c);
    set(h,'LineWidth',3)
    h=AC_display(vert0,'close',['r--']);
    drawnow, pause(.5)
end
%% Save segments

if SAVE_SEGMENTS == 1 
    saveFileName = 'VFC_segment.mat';
    save(saveFileName,'vert','Imagefile');
end
