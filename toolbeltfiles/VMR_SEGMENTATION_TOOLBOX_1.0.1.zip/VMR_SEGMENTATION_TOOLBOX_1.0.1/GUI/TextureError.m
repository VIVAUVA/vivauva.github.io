function EdgeError_t = TextureError(m_i,w_i,DOOG_theta)

len=length(w_i);
sum=zeros(size(m_i{1}));

for i=1:1:len
    
   text_theta_err=w_i(i)*abs(getIntensityError(m_i{i},DOOG_theta));
   %text_theta_err=w_i(i)*abs((m_i{i}*DOOG_theta));
   sum=sum+text_theta_err;
    
end
EdgeError_t=sum;
