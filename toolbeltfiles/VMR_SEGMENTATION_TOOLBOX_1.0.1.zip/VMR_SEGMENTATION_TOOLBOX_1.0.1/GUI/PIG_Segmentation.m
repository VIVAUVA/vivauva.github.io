function [numseg vert]= PIG_Segmentation(Imagefile)

% Poisson inverse gradient (PIG) automatic initialization example.
%
%     See also AMT, EXAMPLE_VFC, AM_PIG, AC_ISOLINE, AM_VFC.
%
%     Reference
%     [1] Bing Li and Scott T. Acton, "Active contour external force using
%     vector field convolution for image segmentation," Image Processing,
%     IEEE Trans. on, vol. 16, pp. 2096-2106, 2007.
%     [2] Bing Li and Scott T. Acton, "Automatic Active Model
%     Initialization via Poisson Inverse Gradient," Image Processing,
%     IEEE Trans. on, vol. 17, pp. 1406-1420, 2008.
%
% (c) Copyright Bing Li 2005 - 2009.

%  clear all
% disp('======================================')
% disp('Poisson inverse gradient (PIG) example')

% parameter settings
% disp('Initializing parameters ...')

SAVE_AVI = 0;   % set it to 1 if you want to see the deformation and save it as .avi movie
SAVE_SEGMENT_PNG = 0;
SAVE_SEGMENTS = 0;
NUM_SEGMENTS_SEL = 0;

alpha = .5;
beta = .1;
tau = .5;
clr = {'r','m','b','y','r--','b--','m--'};
maxEta1=6;

Image = imread(Imagefile); %Change to Image = handles.Image; and delete 2 lines before
tic
[x y z] = size(Image);

if z ==3
    I0 = rgb2gray(Image);
else
    I0 = Image;
end

% if size(I0,1)>255 || size(I0,2)>255
%         I0=imresize(I0,[255 size(I0,2)*255/size(I0,1)]);
% end

size_im_test=size(I0);   %required for zernike
I = I0;
% Compute edge map and external force field
% disp('Computing edge map and force field...')
f = edge(I,'canny',.2,1.5);
%f = edge(I,'log'); %Did not work well at all, froze matlab
omega = ~f;

K = AM_VFK(2, 64, 'power',3);
Fext = AM_VFC(f, K, 1);

method = 3;
lambda = 5:5:50;    % isovalues
eta = maxEta1; %input('How many objects? ');  % # of models to initialize

E = AM_PIG(Fext, omega, double(f));
[vert isoValue] = AC_isoLine(E, lambda, eta);  %Currently using new code

% display
K = length(vert);
ModelNum(method) = K;

c = 'g--';

%imshow(I0) %Take out in the GUI

%     for k = 1:K
%         h = AC_display(vert{k},'close',c);
%         set(h,'LineWidth',3)
%     end
%     drawnow, pause(.5)
%This is the end of the PIG algorithm

%The deformation of a snake begins here
area_previous = zeros(1,K);
for k = 1:K,
    area_previous(k) = polyarea(vert{k}(:,1),vert{k}(:,2));
end
area_diff = area_previous;  % compute areas for converge condition
iter = 0;
flagsConverged = zeros(1,K);

while ~all(flagsConverged)
    iter = iter+3;
    flagsConverged = abs(area_diff)<1;  % converge condition: area change less than 1
    for k = 1:K,
        if flagsConverged(k)
            continue
        end
        vert{k} = AC_deform(vert{k},alpha,beta,tau,Fext,3);
        area = polyarea(vert{k}(:,1),vert{k}(:,2));
        area_diff(k) = area - area_previous(k);
        area_previous(k) = area;
        
        if mod(iter,9)==0,
            vert{k} = AC_remesh2(vert{k},1); %Change back once Remesh is fast
        end
    end
    
end

numseg = K;
%         for k = 1:K
%             try
%                 h = AC_display(vert{k},'close',clr{k});
%                 set(h,'linewidth',3)
%             end
%         end
%         drawnow, pause(.5)

%toc
%saveFileName = strcat(pathName,'\single_im.mat');
%save(saveFileName,'vert','fileName','maxEta1');

%% Energy Map

%             figure(3) % display E with isolines
%             imagesc(E-max(E(:))+min(E(:))-1);
%             hold on
%             contour(E,lambda,'linewidth',2.5)
%             hold off
%
%             axis image, axis off
%             set(gca,'Clim',[min(E(:))*2-max(E(:))-1,max(E(:))])
%             colormap([gray(128); jet(32) ;jet(96)]);