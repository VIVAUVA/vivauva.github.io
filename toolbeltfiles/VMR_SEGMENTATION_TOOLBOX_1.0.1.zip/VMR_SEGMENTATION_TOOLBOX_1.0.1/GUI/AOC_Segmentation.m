
% find 'dominant' shape for each image
% Use Area Open Close...
% Scott Acton 2006-12
function [numseg vert]= AOC_Segmentation(Imagefile)

%clear all;
%close all;
Npoints=128;
IMAGES=1;
i=1;

ahull=0;
ahullMIN=70;


% [file1, path1]=uigetfile('*.jpg', 'Select Template image to load');
% 
% inputFile=strcat(path1,file1);
% Image=imread(inputFile,'jpeg');
%         figure(1),imagesc(Image),drawnow;

Image=imread(Imagefile);
[height, width, bands]=size(Image);
% if(height>600 || width>600),
%     Image=Image(1:2:height,1:2:width,:);
%     [height, width, bands]=size(Image);
% end

I=double(rgb2gray(Image));
[height,width]=size(I);

Iout=I;

%**********************************
areamin=round(height*width*(.01));
% areamin=5;
areamax=round(height*width*(.6));
%**********************************

nosegments=0;
%find dark segments
for tau=100:50:200,
    binaryimage=Iout<=tau;
    binaryimage=bwareaopen(binaryimage,areamin);
%     figure, imagesc(binaryimage),colormap(gray), axis image, drawnow
    
    binaryimage=imfill(binaryimage,'holes');
%     figure, imagesc(binaryimage), colormap(gray),axis image, drawnow
    
    %are there any good segments?
    [LL, NN]=bwlabel(binaryimage);
    %figure,imagesc(LL),axis image, drawnow
    %NN
%     pause
    if NN,
        for i=1:NN,
%             i
            howmany=length(find(LL==i));
%             howmany
            if howmany>areamin && howmany<areamax;
                nosegments=nosegments+1;
                segmentimage=zeros(size(I));
                segmentimage(find(LL==i))=1;
                [B,L] = bwboundaries(segmentimage);
                vert{nosegments}=B;
            end
        end
    end
    
    
end
%find bright segments
for tau=100:50:200,
    binaryimage=Iout>=tau;
    binaryimage=bwareaopen(binaryimage,areamin);
%     figure, imagesc(binaryimage),colormap(gray), axis image, drawnow
    
    binaryimage=imfill(binaryimage,'holes');
%     figure, imagesc(binaryimage), colormap(gray),axis image, drawnow
    
    %are there any good segments?
    [LL, NN]=bwlabel(binaryimage);
    if NN,
        for i=1:NN,
%             i
            howmany=length(find(LL==i));
%             howmany
            if howmany>areamin && howmany<areamax;
                nosegments=nosegments+1;
                segmentimage=zeros(size(I));
                segmentimage(find(LL==i))=1;
                [B,L] = bwboundaries(segmentimage);
                vert{nosegments}=B;
            end
        end
    end
    
    
end
numseg = nosegments;
%colorstring='ymcrgb';

% figure
% imshow(Image),axis image, hold on;
% for i=1:nosegments,
%     r=cell2mat(vert{i});
%     r=fliplr(r);
%     yocolor=colorstring(mod(i,6)+1);
%     yocolor=strcat(yocolor,'-');
%     h(1) = AC_display(r,'close',yocolor);
%     
%     set(h,'LineWidth',1);
%     title('These are the segments')
% end
%hold off, drawnow



%segments could be redundant

%output in vert{}


