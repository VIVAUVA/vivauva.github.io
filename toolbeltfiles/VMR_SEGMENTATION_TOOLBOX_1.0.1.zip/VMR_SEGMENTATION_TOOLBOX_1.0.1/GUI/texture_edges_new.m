% Edge Flow: Code
% Author: Suvadip Mukherjee

function [text_edge,text_angel,MaxProbArray,MaxTextureArray,TextureEdgeMap,tex_img,N] = texture_egdes_new(Img);

displayGD = 0;
displayDOOG = 0;
displayGrad = 0;
displayEdgeProb = 0;
%%
%Img = imread('mra5.jpg');



%  if length(size(Img)) > 2
%     Img = double(rgb2gray(Img));
%  else
%      Img = double(Img);
%  end
%Img = imresize(Img,[300 300]);
%Img = imresize(Img,0.5);
[row col] = size(Img);

%% Compute the Gauss derivatives in each directions
frac = 8;
theta = 0:pi/frac:2*pi;
sigma = 4;
h = 8*sigma;
% d = 1*sigma;
d = 2*sigma;
GD_theta = cell(length(theta),1);
DOOG_theta = cell(length(theta),1);
for i = 1 : length(theta)
    angle = theta(i);
    [GD_theta{i,1} DOOG_theta{i,1}] = getGD_DOOG(sigma,h,d,angle);
end

%% Display the obtained GD
if displayGD
    for i = 1 : length(theta)
        [X Y] = meshgrid(-h/2:h/2,-h/2:h/2);
        Z = GD_theta{i};
        figure;surf(X,Y,Z); drawnow;
    end
end

%% display DOOG
if displayDOOG
    for i = 1 : length(theta)
        [X Y] = meshgrid(-h/2:h/2,-h/2:h/2);
        Z = DOOG_theta{i};
        figure;surf(X,Y,Z); drawnow;
    end
end

%% Compute the texture features
stage=6;
orientation=12;
N=stage*orientation;
Ul=1/(4*sigma);
Uh=0.45;
flag=1;
[texture_F,tex_img] = GaborFeatures_new(Img, stage, orientation, Ul, Uh, flag); % first colomn gives the amplitude 
%%
%=1;
for k=1:N
    
      m_i{k}=abs(tex_img{k});
      w_i(k)=1/sum(m_i{k}(:));
    
end
 
%% computing texture_edge
TextureEdgeMap = cell(length(theta),1);
for i = 1 : length(theta)
    TextureEdgeMap{i} = textureEdge(m_i,w_i,GD_theta{i}); 
    TextureEdgeMap{i} = (TextureEdgeMap{i} - min(TextureEdgeMap{i}(:)))/(max(TextureEdgeMap{i}(:))-min(TextureEdgeMap{i}(:)));
end



%%
if displayGrad
    for i = 1 : length(theta)
        figure;imagesc(TextureEdgeMap{i});colormap('gray'); drawnow
    end
end

%% Compute the edge probability
TetureEdgeProb = cell(length(theta),1);
for i = 1 : length(theta)
    EdgeError_theta = [];
    EdgeError_theta_opposite = [];
    EdgeError_theta = abs(TextureError(m_i,w_i,DOOG_theta{i})); 
    
    oppIndex = mod(i+frac-1,length(theta))+1;
    
    EdgeError_theta_opposite = abs(TextureError(m_i,w_i,DOOG_theta{oppIndex})); 
    TextureEdgeProb{i} = EdgeError_theta./(EdgeError_theta+EdgeError_theta_opposite+1);
    TextureEdgeProb{i} = (TextureEdgeProb{i} - min(TextureEdgeProb{i}(:)))/(max(TextureEdgeProb{i}(:))-min(TextureEdgeProb{i}(:)));
    TextureEdgeProb_opp{i} = EdgeError_theta_opposite./(EdgeError_theta+EdgeError_theta_opposite+1);
    TextureEdgeProb_opp{i} = (TextureEdgeProb_opp{i} - min(TextureEdgeProb_opp{i}(:)))/(max(TextureEdgeProb_opp{i}(:))-min(TextureEdgeProb_opp{i}(:)));
end
%%



if displayEdgeProb
    
    for i = 1 : length(theta)
        figure;imagesc(TextureEdgeProb{i});colormap('gray'); drawnow
    end
    
end
 
%% Find the most Probable Edgemap

MaxProbArray = zeros(row,col);
MaxTextureArray = zeros(row,col);
angleArray = zeros(row,col);
for i = 1 : row
    for j = 1 : col
        maxval = -Inf;
        maxangle = -1;
        theta_sum = 0;
        for k = 1 : length(theta)
            array = TextureEdgeProb{k};
%             disp([array(i,j) maxval]);
%             pause;
            if array(i,j)> maxval 
                maxval = array(i,j);
                maxangle = k;
            end
        end
       MaxProbArray(i,j) = maxval; 
       MaxTextureArray(i,j) = TextureEdgeMap{maxangle}(i,j);
       angleArray(i,j) = theta(maxangle);
    end
end
text_angel = angleArray;


%%

EdgeTex = MaxProbArray.*MaxTextureArray;
EdgeTex = (EdgeTex - min(EdgeTex(:)))/(max(EdgeTex(:))-min(EdgeTex(:)));

text_edge=EdgeTex;
