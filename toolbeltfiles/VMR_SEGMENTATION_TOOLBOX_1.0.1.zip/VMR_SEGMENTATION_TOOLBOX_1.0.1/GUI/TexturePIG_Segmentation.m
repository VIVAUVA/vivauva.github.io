

function [numseg vert] = TexturePIG_Segmentation(Imagefile)
%clc
%clear

displayGD = 0;
displayDOOG = 0;
displayGrad = 0;
displayEdgeProb = 0;

Img = imread(Imagefile);
%Img=double((Img(:,:,3)));
%Img = imresize(Img,0.5);
%Img=double((Img(:,:,3)));
%%
 if length(size(Img)) > 2
     Img = im2double(rgb2gray(Img));
 else
     Img = im2double(Img);
 end
%Img = imresize(Img,[300 300]);
%Img = imresize(Img,0.5);
[row col] = size(Img);

%% Compute the Gauss derivatives in each directions
frac = 8;
theta = 0:pi/frac:2*pi;
sigma = 4;
h = 6*sigma;
% d = 1*sigma;
d = 2*sigma;
GD_theta = cell(length(theta),1);
DOOG_theta = cell(length(theta),1);
for i = 1 : length(theta)
    angle = theta(i);
    [GD_theta{i,1} DOOG_theta{i,1}] = getGD_DOOG(sigma,h,d,angle);
end

%% Display the obtained GD
if displayGD
    for i = 1 : length(theta)
        [X Y] = meshgrid(-h/2:h/2,-h/2:h/2);
        Z = GD_theta{i};
        figure;surf(X,Y,Z); drawnow;
    end
end

%% display DOOG
if displayDOOG
    for i = 1 : length(theta)
        [X Y] = meshgrid(-h/2:h/2,-h/2:h/2);
        Z = DOOG_theta{i};
        figure;surf(X,Y,Z); drawnow;
    end
end

%% Compute the edge map in each direction
IntensityEdgeMap = cell(length(theta),1);
for i = 1 : length(theta)
    IntensityEdgeMap{i} = getEdgeMap(Img,GD_theta{i}); 
    IntensityEdgeMap{i} = (IntensityEdgeMap{i} - min(IntensityEdgeMap{i}(:)))/(max(IntensityEdgeMap{i}(:))-min(IntensityEdgeMap{i}(:)));
end
%%
if displayGrad
    for i = 1 : length(theta)
        figure;imagesc(IntensityEdgeMap{i});colormap('gray'); drawnow
    end
end

%% Compute the edge probability
IntensityEdgeProb = cell(length(theta),1);
for i = 1 : length(theta)
    EdgeError_theta = [];
    EdgeError_theta_opposite = [];
    EdgeError_theta = abs(getIntensityError(Img,DOOG_theta{i})); 
    oppIndex = mod(i+frac-1,length(theta))+1;
    EdgeError_theta_opposite = abs(getIntensityError(Img,DOOG_theta{oppIndex})); 
    IntensityEdgeProb{i} = EdgeError_theta./(EdgeError_theta+EdgeError_theta_opposite+1);
    IntensityEdgeProb{i} = (IntensityEdgeProb{i} - min(IntensityEdgeProb{i}(:)))/(max(IntensityEdgeProb{i}(:))-min(IntensityEdgeProb{i}(:)));
end
%%
if displayEdgeProb
    for i = 1 : length(theta)
        figure;imagesc(IntensityEdgeProb{i});colormap('gray'); drawnow
    end
end
 
%% Find the most Probable Edgemap

MaxProbArray = zeros(row,col);
MaxIntensityArray = zeros(row,col);
angleArray = zeros(row,col);
for i = 1 : row
    for j = 1 : col
        maxval = -Inf;
        maxangle = -1;
        for k = 1 : length(theta)
            array = IntensityEdgeProb{k};
%             disp([array(i,j) maxval]);
%             pause;
            if array(i,j)> maxval 
                maxval = array(i,j);
                maxangle = k;
            end
        end
       MaxProbArray(i,j) = maxval; 
       MaxIntensityArray(i,j) = IntensityEdgeMap{maxangle}(i,j);
       angleArray(i,j) = theta(maxangle);
    end
end

%%
%figure;
%imagesc(MaxIntensityArray);colormap('gray');title('Intensity without multiplying by Probability');
% figure;
% imagesc(MaxProbArray.*MaxIntensityArray);colormap('gray');
%%

EdgeIntensity = MaxProbArray.*MaxIntensityArray;
%EdgeIntensity = MaxIntensityArray;
EdgeIntensity = (EdgeIntensity - min(EdgeIntensity(:)))/(max(EdgeIntensity(:))-min(EdgeIntensity(:)));
%%
[edge_int1,angel_text,MaxProbArray_text,MaxTextureArray,TextureEdgeMap]=texture_edges_new(Img);

%% computing VFC
f = edge(Img,'canny',.2,1.5);
K1 = AM_VFK(2, 64, 'power',3);
Fext1 = AM_VFC(f, K1, 1);

%total edge intensity
%EdgeIntensity_total=0*EdgeIntensity+1*edge_int1;
%Fext1 = AM_VFC(EdgeIntensity_total, K1, 1);
%Fext2 = AM_VFC(EdgeIntensity, K1, 1);
%figure;
%imshow(EdgeIntensity);title('Edge Intensity(multiplied by Probability col)');
%figure();
%imshow(edge_int1);title('Edge Intensity(multiplied by Probability text)');


EF_vect1 = 0.2*EdgeIntensity.*cos(angleArray)+0.3*Fext1(:,:,1)+0.5*edge_int1.*cos(angel_text);%angel_text for edge_int1
EF_vect2 = 0.2*EdgeIntensity.*sin(angleArray)+0.3*Fext1(:,:,2)+0.5*edge_int1.*sin(angel_text);
%%
%figure; imagesc(Img);hold on;
%[x y] = meshgrid(1:col,1:row);
%quiver(x,y,EF_vect1,EF_vect2);

%% Experiments with PIG
E = [];
Fext = zeros(row,col,2);
Fext(:,:,1) = EF_vect1;
Fext(:,:,2) = EF_vect2;
f = edge(Img,'canny',.2,1.5);
%f = 0.3*f + 0.5*im2bw(MaxTextureArray)+ 0.2*im2bw(MaxIntensityArray);
omega =~(f); %
E = 0.3*AM_PIG(Fext,omega,f);
%E = AM_PIG(Fext,omega,MaxIntensityArray);
%%
%%***********************************
P=ceil(E);
eta=3*((max(max(P))-min(min(P))));
%%*************************************
%%
E = (E - min(E(:)))/(max(E(:))-min(E(:)));
%eta = 15;
%%
lambda = 0:.05:1;
% figure(3) % display E with isolines
% imagesc(Img);
% colormap('gray')
% hold on
% [C,h] = contour(E,lambda,'linewidth',2.5,'EdgeColor','r');
% 
% clabel(C,h);
% hold off

%%
[vert1 isoValue] = AC_isoLine(E, lambda,eta);
%%
%%****************************************
[vert K_new] = snake_deformEdit(vert1,Fext)


numseg = K_new;
    
    
    

