function varargout = VMR_segmentation(varargin)
%VMR_SEGMENTATION M-file for VMR_segmentation.fig
%      VMR_SEGMENTATION, by itself, creates a new VMR_SEGMENTATION or raises the existing
%      singleton*.
%
%      H = VMR_SEGMENTATION returns the handle to a new VMR_SEGMENTATION or the handle to
%      the existing singleton*.
%
%      VMR_SEGMENTATION('Property','Value',...) creates a new VMR_SEGMENTATION using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to VMR_segmentation_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      VMR_SEGMENTATION('CALLBACK') and VMR_SEGMENTATION('CALLBACK',hObject,...) call the
%      local function named CALLBACK in VMR_SEGMENTATION.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help VMR_segmentation

% Last Modified by GUIDE v2.5 26-Nov-2013 17:01:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @VMR_segmentation_OpeningFcn, ...
    'gui_OutputFcn',  @VMR_segmentation_OutputFcn, ...
    'gui_LayoutFcn',  [], ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before VMR_segmentation is made visible.
function VMR_segmentation_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for VMR_segmentation
handles.output = hObject;
handles.queryImgFile = cell(1, 2);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes VMR_segmentation wait for user response (see UIRESUME)
% uiwait(handles.figure1);










% --- Outputs from this function are returned to the command line.
function varargout = VMR_segmentation_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in QueryTypeSelectPopMenu.
function QueryTypeSelectPopMenu_Callback(hObject, eventdata, handles)
% hObject    handle to QueryTypeSelectPopMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns QueryTypeSelectPopMenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from QueryTypeSelectPopMenu

% Query type single or database


% --- Executes during object creation, after setting all properties.
function QueryTypeSelectPopMenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to QueryTypeSelectPopMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in AlgSelPopMenu.
function AlgSelPopMenu_Callback(hObject, eventdata, handles)
% hObject    handle to AlgSelPopMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns AlgSelPopMenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from AlgSelPopMenu

% Select ALgorithms for segmentation





% --- Executes during object creation, after setting all properties.
function AlgSelPopMenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AlgSelPopMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on pushbutton1 and none of its controls.
function pushbutton1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in NumSegmentselPopMenu.
function NumSegmentselPopMenu_Callback(hObject, eventdata, handles)
% hObject    handle to NumSegmentselPopMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns NumSegmentselPopMenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from NumSegmentselPopMenu


% --- Executes during object creation, after setting all properties.
function NumSegmentselPopMenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NumSegmentselPopMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function NumSeg_Callback(hObject, eventdata, handles)
% hObject    handle to NumSeg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NumSeg as text
%        str2double(get(hObject,'String')) returns contents of NumSeg as a double


% --- Executes during object creation, after setting all properties.
function NumSeg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NumSeg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in SaveSegData.
function SaveSegData_Callback(hObject, eventdata, handles)
% hObject    handle to SaveSegData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns SaveSegData contents as cell array
%        contents{get(hObject,'Value')} returns selected item from SaveSegData


% --- Executes during object creation, after setting all properties.
function SaveSegData_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SaveSegData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in SaveSegImages.
function SaveSegImages_Callback(hObject, eventdata, handles)
% hObject    handle to SaveSegImages (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns SaveSegImages contents as cell array
%        contents{get(hObject,'Value')} returns selected item from SaveSegImages


% --- Executes during object creation, after setting all properties.
function SaveSegImages_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SaveSegImages (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SelectImagePushButton.
function SelectImagePushButton_Callback(hObject, eventdata, handles)
% hObject    handle to SelectImagePushButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[img_file, img_path] = uigetfile('*.jpeg;*.jpg;*.bmp;*.png;*.tiff', 'Please select an image.');
handles.queryImgFile = [img_path img_file];

% Set the text label to show the filename selected
%set(handles.queryImgPathTxt, 'String', img_file);

% Display the image in the preview panel
query_img = imread(fullfile(img_path, img_file));

axes(handles.axes1);
image(query_img)
set(handles.axes1, 'Visible', 'off');
% Update handles structure
guidata(hObject, handles);



% --- Executes on button press in StartSegment.
function StartSegment_Callback(hObject, eventdata, handles)
% hObject    handle to StartSegment (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
segment_algo = get(handles.AlgSelPopMenu,'value')

switch segment_algo
    case 1
        error('You must select a search algorithm!')
   
    case 2
        %PIG
        cla (handles.axes2)
        axes(handles.axes2);
        image(imread(handles.queryImgFile));axis tight;
        hold on
        [numseg vert]= PIG_Segmentation(handles.queryImgFile);
        colorstring='ymbrgb';
        for i=1:1:numseg
            yocolor=colorstring(mod(i,6)+1);
            yocolor=strcat('-',yocolor);
            plot(vert{i}(:,1),vert{i}(:,2),yocolor,'linewidth',2);
            hold on
        end
        set(handles.axes2, 'Visible', 'off');
    case 3 
        %PIG with VFC and texture
        cla (handles.axes2)
        axes(handles.axes2);
        image(imread(handles.queryImgFile));axis tight;
        hold on
        [numseg vert]= TexturePIG_Segmentation(handles.queryImgFile);
        colorstring='ymbrgb';
        for i=1:1:numseg
            yocolor=colorstring(mod(i,6)+1);
            yocolor=strcat('-',yocolor);
            plot(vert{i}(:,1),vert{i}(:,2),yocolor,'linewidth',2);
            hold on
        end
        set(handles.axes2, 'Visible', 'off');
        
    case 4
        %AOC
        cla (handles.axes2)
        axes(handles.axes2);
        image(imread(handles.queryImgFile));axis tight;
        hold on
        [numseg vert]= AOC_Segmentation(handles.queryImgFile);
        colorstring='ymbrgb';
        for i=1:1:numseg
            r=cell2mat(vert{i});
            r=fliplr(r);
            yocolor=colorstring(mod(i,6)+1);
            yocolor=strcat('-',yocolor);
            plot(r(:,1),r(:,2),yocolor,'linewidth',2);
            hold on
        end
        set(handles.axes2, 'Visible', 'off');
 
        
        
        
        
end
% Update handles structure
guidata(hObject, handles);
