function [GD DOOG_theta] = getGD_DOOG(sigma,h,d,theta)
%GETGD : returns the hXh gaussian derivative in direction theta

[X Y] = meshgrid(-h/2:h/2,-h/2:h/2);

GD = [];
G = (exp(-(X.^2+Y.^2)/(2*sigma*sigma)))/(1.414*sqrt(pi)*sigma);

u1 = cos(theta);
u2 = sin(theta);

% Formula obtained by taking directional derivative
GD = -G.*(u1*X + u2*Y)/(sigma*sigma);


G2 = exp(-((X+d*u1).^2+(Y+d*u2).^2)/(2*sigma*sigma))/(1.414*sqrt(pi)*sigma);

DOOG = G - G2;
% DOOG_theta = sqrt((DOOG*u1).^2+(DOOG*u2).^2);
DOOG_theta = DOOG;
end

