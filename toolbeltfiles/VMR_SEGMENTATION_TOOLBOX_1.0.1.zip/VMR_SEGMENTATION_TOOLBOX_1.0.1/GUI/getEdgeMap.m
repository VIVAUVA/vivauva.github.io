function [edgeMap ] = getEdgeMap(I,mask)
%GETEDGEMAP: obtain the edgemap in direction theta 
    
edgeMap = imfilter(I,mask,'same','conv');

end

