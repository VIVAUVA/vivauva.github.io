function [error] = getIntensityError(I,mask)
%GETINTENSITYERROR error of edge prediction in direction theta

error = imfilter(I,mask,'same','conv');


end

