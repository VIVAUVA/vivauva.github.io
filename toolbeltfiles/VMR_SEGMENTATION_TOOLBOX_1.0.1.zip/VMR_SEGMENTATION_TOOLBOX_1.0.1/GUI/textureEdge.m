function TextureEdgeMap = textureEdge(m_i,w_i,GD_theta) 


len=length(w_i);
sum=zeros(size(m_i{1}));

for i=1:1:len
    
   text_theta=w_i(i)*abs(getEdgeMap(m_i{i},GD_theta));
   %text_theta=abs(getEdgeMap(m_i{i},GD_theta));
   sum=sum+text_theta;
    
end
TextureEdgeMap=sum;

