function [numseg vert]= AOC_Segmentation(Imagefile)

%% Use Area Morphology for image segmentation
%
%     Reference
%
%     S.T.Acton, "Fast Algorithms for Area Morphology", Digital Signal Processing,
%     Volume 11, Number 3, July 2001 , pp. 187-203(17)
%
%
% (c) Copyright S.T.Acton 2006 - 2012.


DISPLAY_BinaryImages=0;
DISPLAY_SEGMENT = 1;
SAVE_SEGMENTS =1;

tau_low_lim = 100;
tau_step = 50;
tau_upper_lim = 200;
colorstring='ymcrgb';

Image=imread(Imagefile);
[height, width, bands]=size(Image);

I=double(rgb2gray(Image));
[height,width]=size(I);

Iout=I;

%**********************************
areamin=round(height*width*(.01));
% areamin=5;
areamax=round(height*width*(.6));
%**********************************

nosegments=0;
%find dark segments
for tau=tau_low_lim:tau_step:tau_upper_lim
    binaryimage=Iout<=tau;
    binaryimage=bwareaopen(binaryimage,areamin);
    
    if DISPLAY_BinaryImages==1
        figure, imagesc(binaryimage),colormap(gray), axis image, drawnow
    end
    
    binaryimage=imfill(binaryimage,'holes');
    
    if DISPLAY_BinaryImages==1
        figure, imagesc(binaryimage), colormap(gray),axis image, drawnow
    end
    
    %look for good segments
    [LL, NN]=bwlabel(binaryimage);
    
    if NN,
        for i=1:NN,
            
            howmany=length(find(LL==i));
            %howmany segments
            if howmany>areamin && howmany<areamax;
                nosegments=nosegments+1;
                segmentimage=zeros(size(I));
                segmentimage(find(LL==i))=1;
                [B,L] = bwboundaries(segmentimage);
                vert{nosegments}=B;
            end
        end
    end
    
    
end
%find bright segments
for tau=100:50:200,
    binaryimage=Iout>=tau;
    binaryimage=bwareaopen(binaryimage,areamin);
    if DISPLAY_BinaryImages==1
        figure, imagesc(binaryimage),colormap(gray), axis image, drawnow
    end
    
    binaryimage=imfill(binaryimage,'holes');
    
    if DISPLAY_BinaryImages==1
        figure, imagesc(binaryimage),colormap(gray), axis image, drawnow
    end
    
    %look for good segments
    [LL, NN]=bwlabel(binaryimage);
    if NN,
        for i=1:NN,
            
            howmany=length(find(LL==i));
            %howmany segments
            if howmany>areamin && howmany<areamax;
                nosegments=nosegments+1;
                segmentimage=zeros(size(I));
                segmentimage(find(LL==i))=1;
                [B,L] = bwboundaries(segmentimage);
                vert{nosegments}=B;
            end
        end
    end
    if nosegments == 0
        error('No good segments found, change tau')
    end
    
end
numseg = nosegments;

%display the segments 
if DISPLAY_SEGMENT ==1
    figure
    imshow(Image),axis image, hold on;
    for i=1:nosegments,
        r=cell2mat(vert{i});
        r=fliplr(r);
        yocolor=colorstring(mod(i,6)+1);
        yocolor=strcat(yocolor,'-');
        h(1) = AC_display(r,'close',yocolor);
        
        set(h,'LineWidth',1);
        title('These are the segments')
    end
    hold off, drawnow
end
%save as matfile
if SAVE_SEGMENTS ==1
    saveFileName = 'AOC_segments.mat';
    save(saveFileName,'vert','Imagefile','numseg');
end




