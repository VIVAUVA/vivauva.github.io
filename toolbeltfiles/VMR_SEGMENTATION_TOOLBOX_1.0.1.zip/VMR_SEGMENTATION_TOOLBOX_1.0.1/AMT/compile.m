mex AM_gradient_c.c
mex AM_GVF_c.c
mex AM_laplacian_c.c


