%----------------------------------------------------------------------
%
%           I : Grayscale image to extract features from.  Image must be
%               whose widths are powers of 2
%       stage : specify which gabor filter is selected.
%               Determines how many frequency levels (paper uses 4)
% orientation : specify which gabor filter is selected.
%               Determines how many directions (paper uses 6)
%          Ul : specify the minimum center frequency (paper uses 0.05)
%          Uh : specify the maximum center frequency (paper uses 0.4)
%        flag : 1 -> remove the dc value of the real part of Gabor
%               0 -> not to remove
%               (paper uses 0)
%        mask : (optional) bit mask to determine which pixels to use
%
% This code has been obtained form
% http://vision.ece.ucsb.edu/texture/software/ with minor changes in the
% code
%----------------------------------------------------------------------
function[D] = GaborFeatures_new(I, stage, orientation, Ul, Uh, flag, varargin)

[height,width] = size(I);
N = height;
M = width;

freq = [Ul, Uh];
j = sqrt(-1);
GW = {};

% --------------- generate the Gabor FFT data ---------------------
for s = 1:stage,
    for n = 1:orientation,
        [Gr,Gi] = Gabor(N,M,[s n],freq,[stage orientation],flag);
        F = (Gr+j*Gi);
        F(1,1) = 0;
        GW{s,n} = F;
    end;
end;

% ------------------ Extract the filter response -------------------------
if length(varargin) > 0;
    mask = varargin{1};
    [D] = Fea_Gabor_brodatz_new(I, GW, stage, orientation, mask);
else
    [D] = Fea_Gabor_brodatz_new(I, GW, stage, orientation);
end
