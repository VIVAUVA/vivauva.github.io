function [numseg vert] = TexturePIG_Segmentation(Imagefile)
% Texture and VFC as external force field and Automatic initialization by
% PIG
%
%     Reference
%     [1] Bing Li and Scott T. Acton, "Active contour external force using
%     vector field convolution for image segmentation," Image Processing,
%     IEEE Trans. on, vol. 16, pp. 2096-2106, 2007.
%     [2] Bing Li and Scott T. Acton, "Automatic Active Model
%     Initialization via Poisson Inverse Gradient," Image Processing,
%     IEEE Trans. on, vol. 17, pp. 1406-1420, 2008.
%


SAVE_SEGMENTS = 0; % set it to 1 if you want to save the segments as .mat file else 0
NUM_SEGMENTS_SEL = 1;% set it to 0 if you need to fix the number of segments for the image (num_segments)
DISPLAY_DETAILS = 0;% set it to 1 if you want to see the initial segments
DISPLAY_SEGMENTATION = 1;%set it to 0 if you do not want to display the segmentation result 
DISCARD = 1;% set it to 0 if you do not want to discard segments with relatively smaller area 
num_segments = 1; % change the number if NUM_SEGMENTS_SEL = 0;
% parameters for snake iteration
alpha = .3;
beta = .1;
tau = .5;
colorstring='ymcrgb';

% parameters for Gauss derivative
frac = 8;
theta = 0:pi/frac:2*pi;
sigma = 4;
h = 6*sigma;
d = 2*sigma;
%%
Img = imread(Imagefile);


 if length(size(Img)) > 2
     Img = im2double(rgb2gray(Img));
 else
     Img = im2double(Img);
 end

[row col] = size(Img);

%% Compute the Gauss derivatives in each directions for intensity

GD_theta = cell(length(theta),1);
DOOG_theta = cell(length(theta),1);
for i = 1 : length(theta)
    angle = theta(i);
    [GD_theta{i,1} DOOG_theta{i,1}] = getGD_DOOG(sigma,h,d,angle);
end

%% Compute the edge map in each direction
IntensityEdgeMap = cell(length(theta),1);
for i = 1 : length(theta)
    IntensityEdgeMap{i} = getEdgeMap(Img,GD_theta{i}); 
    IntensityEdgeMap{i} = (IntensityEdgeMap{i} - min(IntensityEdgeMap{i}(:)))/(max(IntensityEdgeMap{i}(:))-min(IntensityEdgeMap{i}(:)));
end

%% Compute the edge probability for intensity
IntensityEdgeProb = cell(length(theta),1);
for i = 1 : length(theta)
    EdgeError_theta = [];
    EdgeError_theta_opposite = [];
    EdgeError_theta = abs(getIntensityError(Img,DOOG_theta{i})); 
    oppIndex = mod(i+frac-1,length(theta))+1;
    EdgeError_theta_opposite = abs(getIntensityError(Img,DOOG_theta{oppIndex})); 
    IntensityEdgeProb{i} = EdgeError_theta./(EdgeError_theta+EdgeError_theta_opposite+1);
    IntensityEdgeProb{i} = (IntensityEdgeProb{i} - min(IntensityEdgeProb{i}(:)))/(max(IntensityEdgeProb{i}(:))-min(IntensityEdgeProb{i}(:)));
end
 
%% Find the most Probable Edgemap

MaxProbArray = zeros(row,col);
MaxIntensityArray = zeros(row,col);
angleArray = zeros(row,col);
for i = 1 : row
    for j = 1 : col
        maxval = -Inf;
        maxangle = -1;
        for k = 1 : length(theta)
            array = IntensityEdgeProb{k};
            if array(i,j)> maxval 
                maxval = array(i,j);
                maxangle = k;
            end
        end
       MaxProbArray(i,j) = maxval; 
       MaxIntensityArray(i,j) = IntensityEdgeMap{maxangle}(i,j);
       angleArray(i,j) = theta(maxangle);
    end
end
EdgeIntensity = MaxProbArray.*MaxIntensityArray;
EdgeIntensity = (EdgeIntensity - min(EdgeIntensity(:)))/(max(EdgeIntensity(:))-min(EdgeIntensity(:)));
% If you want to display the intensity edgemap and the max probable edge map, uncomment this part
%figure;
%imagesc(MaxIntensityArray);colormap('gray');title('Edge map for intensity');
%figure;
%imagesc(MaxProbArray.*MaxIntensityArray);colormap('gray');title('Max probable Edge map for intensity');

%% For texture edge map (using the function exture_edges_new)
[edge_int1,angel_text,MaxProbArray_text,MaxTextureArray,TextureEdgeMap]=texture_edges_new(Img,frac,theta,sigma,h,d);

% If you want to display the intensity edgemap and the max probable edge map, uncomment this part
%figure;
%imshow(MaxTextureArray);colormap('gray');title('Edge map for texture');
%figure();
%imshow(edge_int1);colormap('gray');title('Max probable edge map for texture');
%% computing VFC
f = edge(Img,'canny',.2,1.5);
K1 = AM_VFK(2, 64, 'power',3);
Fext1 = AM_VFC(f, K1, 1);

%% Computing total external force field

% weights for different force fields
w_intensity = 0.2;
w_texture = 0.5;
w_VFCedge = 0.3;

EF_vect1 = w_intensity*EdgeIntensity.*cos(angleArray)+w_VFCedge*Fext1(:,:,1)+w_texture*edge_int1.*cos(angel_text);%angel_text for edge_int1
EF_vect2 = w_intensity*EdgeIntensity.*sin(angleArray)+w_VFCedge*Fext1(:,:,2)+w_texture*edge_int1.*sin(angel_text);

%% Experiments with PIG
E = [];
Fext = zeros(row,col,2);
Fext(:,:,1) = EF_vect1;
Fext(:,:,2) = EF_vect2;
f = edge(Img,'canny',.2,1.5);
omega =~(f); 
E = 0.3*AM_PIG(Fext,omega,f);

%% Computing the total number of segments required for the 

if NUM_SEGMENTS_SEL == 0 && num_segments==0
    error('number of segments (num_segments) need to be greater than 0')
else if NUM_SEGMENTS_SEL == 0 && num_segments~=0
        eta = num_segments;
    else if NUM_SEGMENTS_SEL == 1
            P=ceil(E);
            eta=3*((max(max(P))-min(min(P))));
        end
    end
end

E = (E - min(E(:)))/(max(E(:))-min(E(:)));
lambda = 0:.05:1;
[vert1 isoValue] = AC_isoLine(E, lambda,eta);
%% snake deformation
[vert K_new] = snake_deformEdit(vert1,Fext,alpha,beta,tau,DISPLAY_DETAILS,DISCARD)
numseg = K_new;
    
%% Display Segments
if DISPLAY_SEGMENTATION 
figure()
imshow(Img)
         for k = 1:numseg
             yocolor=colorstring(mod(k,6)+1);
             yocolor=strcat(yocolor,'-');
            try
                 h = AC_display(vert{k},'close',yocolor);
                 set(h,'linewidth',3)
            end
         end
         drawnow, pause(.5)
end
%% Save File
if SAVE_SEGMENTS 
    saveFileName = '\PIG_VFCTEXTUREsegment.mat';
    save(saveFileName,'vert','Imagefile','numseg');
end