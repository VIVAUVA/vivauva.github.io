%% snake deformation
function [contours K_new] = snake_deformEdit(vert,Fext,alpha,beta,tau,DISPLAY_DETAILS,DISCARD)

K = length(vert);
if DISPLAY_DETAILS
    imshow(Img)
    c = '--g';
    for k = 1:K
        h = AC_display(vert{k},'close',c);
        set(h,'LineWidth',2)
    end
    drawnow, pause(.5)
end
area_previous = zeros(1,K);
%%
for k = 1:K,
    area_previous(k) = polyarea(vert{k}(:,1),vert{k}(:,2));
end
area_diff = area_previous;  % compute areas for converge condition
iter = 0;
flagsConverged = zeros(1,K);

while ~all(flagsConverged)
    iter = iter+3;
    flagsConverged = abs(area_diff)<1;  % converge condition: area change less than 1
    for k = 1:K,
        if flagsConverged(k)
            continue
        end
        vert{k} = AC_deform(vert{k},alpha,beta,tau,Fext,3);
        area = polyarea(vert{k}(:,1),vert{k}(:,2));
        area_diff(k) = area - area_previous(k);
        area_previous(k) = area;
        
        if mod(iter,9)==0,
            vert{k} = AC_remesh(vert{k},1); %Change back once Remesh is fast
        end
    end
    
end

%% Deleting smaller area contours

K_vert = length(vert);
if DISCARD
    for ii=1:1:K_vert
        area_of_cont(ii) = polyarea(vert{ii}(:,1),vert{ii}(:,2));
    end
    
    sum_area = sum(area_of_cont);
    [f_sort_area t_sort_area]=sort(area_of_cont,'descend');
    s1=f_sort_area(1);
    for kk1=2:K_vert
        s1=s1+(f_sort_area(kk1));
        if s1>=0.90*sum_area;
            break
        end
    end
    N_t_area=t_sort_area(1:kk1);
    
    K_1=(N_t_area);
    K_new=size(K_1,2);
    
    
    for it=1:1:K_new
        vert1{it}=vert{K_1(it)};
    end
else
    vert1 = vert;
    K_new = K_vert
end

contours = vert1;
