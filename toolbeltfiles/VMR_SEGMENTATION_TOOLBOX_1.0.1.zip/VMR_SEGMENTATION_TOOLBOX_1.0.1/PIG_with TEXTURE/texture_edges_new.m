function [text_edge,text_angel,MaxProbArray,MaxTextureArray,TextureEdgeMap,tex_img,N] = texture_egdes_new(Img,frac,theta,sigma,h,d);

[row col] = size(Img);

%% Compute the Gauss derivatives in each directions
GD_theta = cell(length(theta),1);
DOOG_theta = cell(length(theta),1);
for i = 1 : length(theta)
    angle = theta(i);
    [GD_theta{i,1} DOOG_theta{i,1}] = getGD_DOOG(sigma,h,d,angle);
end
%% Compute the texture features 
stage=6;
orientation=12;
N=stage*orientation;
Ul=1/(4*sigma);
Uh=0.45;
flag=1;
[tex_img] = GaborFeatures_new(Img, stage, orientation, Ul, Uh, flag); % first colomn gives the amplitude 

for k=1:N
      m_i{k}=abs(tex_img{k});
      w_i(k)=1/sum(m_i{k}(:));
end
%% computing texture_edge
TextureEdgeMap = cell(length(theta),1);
for i = 1 : length(theta)
    TextureEdgeMap{i} = textureEdge(m_i,w_i,GD_theta{i}); 
    TextureEdgeMap{i} = (TextureEdgeMap{i} - min(TextureEdgeMap{i}(:)))/(max(TextureEdgeMap{i}(:))-min(TextureEdgeMap{i}(:)));
end
%% Compute the edge probability
TetureEdgeProb = cell(length(theta),1);
for i = 1 : length(theta)
    EdgeError_theta = [];
    EdgeError_theta_opposite = [];
    EdgeError_theta = abs(TextureError(m_i,w_i,DOOG_theta{i})); 
    oppIndex = mod(i+frac-1,length(theta))+1;
    EdgeError_theta_opposite = abs(TextureError(m_i,w_i,DOOG_theta{oppIndex})); 
    TextureEdgeProb{i} = EdgeError_theta./(EdgeError_theta+EdgeError_theta_opposite+1);
    TextureEdgeProb{i} = (TextureEdgeProb{i} - min(TextureEdgeProb{i}(:)))/(max(TextureEdgeProb{i}(:))-min(TextureEdgeProb{i}(:)));
    TextureEdgeProb_opp{i} = EdgeError_theta_opposite./(EdgeError_theta+EdgeError_theta_opposite+1);
    TextureEdgeProb_opp{i} = (TextureEdgeProb_opp{i} - min(TextureEdgeProb_opp{i}(:)))/(max(TextureEdgeProb_opp{i}(:))-min(TextureEdgeProb_opp{i}(:)));
end
%% Find the most Probable Edgemap
MaxProbArray = zeros(row,col);
MaxTextureArray = zeros(row,col);
angleArray = zeros(row,col);
for i = 1 : row
    for j = 1 : col
        maxval = -Inf;
        maxangle = -1;
        theta_sum = 0;
        for k = 1 : length(theta)
            array = TextureEdgeProb{k};
            if array(i,j)> maxval 
                maxval = array(i,j);
                maxangle = k;
            end
        end
       MaxProbArray(i,j) = maxval; 
       MaxTextureArray(i,j) = TextureEdgeMap{maxangle}(i,j);
       angleArray(i,j) = theta(maxangle);
    end
end
text_angel = angleArray;
%%
EdgeTex = MaxProbArray.*MaxTextureArray;
EdgeTex = (EdgeTex - min(EdgeTex(:)))/(max(EdgeTex(:))-min(EdgeTex(:)));

text_edge=EdgeTex;
