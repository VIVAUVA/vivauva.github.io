function diffuse_image = anisotropicDIFF(I,iteration,k)

% image size
[m,n] = size(I);

% image boundary indices: 
% if i=1, then i-1=1, and when j=1, then j-1=1.
% if i=m, then i+1=m, and when j=n, then j+m=m. 
N = [1, 1:m-1];   % North
S = [2:m+0, m];   % South
E = [2:n+0, n];   % East
W = [1, 1:n-1];   % West

% for large iteration, create a waitbar
if iteration > 20
    h = waitbar(0,'Diffusing...');
end

for run = 1:iteration
    % directional gradients
    dN = I(N,:) - I;
    dS = I(S,:) - I;
    dE = I(:,E) - I;
    dW = I(:,W) - I;

    % diffusion coefficients
    cN = exp(-(dN./k).^2);
    cS = exp(-(dS./k).^2);
    cE = exp(-(dE./k).^2);
    cW = exp(-(dW./k).^2);
    
    % calculate diffused image 
    AD = ( (cN.*dN) + (cS.*dS) + (cE.*dE) + (cW.*dW) )./4 ;
    I = I + AD;

    % normalize to [0 1]
    I = (I-min(I(:)))./(max(I(:))-min(I(:)));
    if iteration > 20
        waitbar(run/iteration)
    end
end

if iteration > 20
    close(h)
end

diffuse_image = I;
