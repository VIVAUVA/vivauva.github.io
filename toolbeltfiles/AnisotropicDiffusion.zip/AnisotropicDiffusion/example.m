%Please cite
%S.T. Acton, "Diffusion partial differential equations for edge detection," in the The Essential Guide to Image Processing, Academic Press, 2009.
% Thanks to Dan Lin for programming
clc
clear all
filename = uigetfile('*.jpg');
%%

I = imread(filename);
I = double(I(:,:,2))./255;
[m,n] = size(I);
Inoise = imnoise(I,'gaussian',0,0.3);


%%
k = .4;
iteration = 75;


% h = waitbar(0,'Please Wait...');
counter = 0;
% simulate different k values
for j = 1:length(k)
    J = Inoise;
    for run = 1:iteration
        % applied AD
        J = anisotropicDIFF(J,1,k(j));
       image(1),imagesc(J),colormap(gray),drawnow
    end
end
%%

