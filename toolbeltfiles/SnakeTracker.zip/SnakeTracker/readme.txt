The folder contains the data and MATLAB code, which is an implementation and a 
demonstration of the snake tracker as presented in [1].  

Content 
I: .\data\:

  i) ves2p1.0028.bmp - ves1p1.0118.bmp: an image sequence recording leukocyte 
     movement in vivo. 
  
  ii) firstimageves2p1c1_gt.bmp: essentially the same as ves1p1.0028.bmp, the first 
     frame to be tracked, except for showing the target leukocyte to be tracked by 
     a black dot.  It is used as a reference image to to start the tracking process. 

  iii) ves2p1c1_gt.mat: ground true position of the target leukocyte, determined 
     manually previously.  It is used for analysis only, e.g., the computation of 
     the mean square tracking error.   

II: .\snake_tracker\: 

  i) example.m: main program.  It provides path info, locates "ves2p1c1_gt.mat", 
     and calls "TrackTrainingSequence.m". 
  
  ii) TrackTrainingSequence.m: locates the target leukocyte in the first frame to be 
     tracked and calls "compute_mgvfsnake_param.m" for tracker implementation.   It 
     also calls "comput_first_untracking_frame.m" to display the frame number of the 
     first untracked frame. 

  iii) compute_mgvfsnake_param.m: calls 

      a) snakematrix.m: to set up the snake matrix; 
 
      b) GVF.m (by Xu and Prince [2]): to compute the edge map; 
	 
	 - sub-routines (see [2] for details): 
           snakedisp.m 
           BoundMirrorEnsure.m 
           BoundMirrorExpand.m
           Bound MirrorShrink.m

      c) movesnake.m: to evolve the snake.

To run the program, simply change the current MATLAB folder to ".\snake_tracker\" and type 
"snake_tracker" in the command window.  A figure window will pop up demonstating the 
tracking performance.  The estimated target leukocyte position is marked with a red 
circle.  The estimated positions ("trackX" and "trackY") are saved as a .mat file under 
..\, which can be used for further analysis, e.g., tracking performance analysis with the 
ground truth positions recorded as "hor" and "vert".



[1] N. Ray, S. T. Acton, and K. Ley, Tracking leukocytes in vivo with shape and size 
constrained active contours, IEEE Trans. Med. Imag. 21 (10) (2002) 1222�C1235.

[2] C. Xu and J. L. Prince, "Snakes, shapes, and gradient vector flow, " IEEE Trans. 
Image Processing, vol. 7, pp.359-369, Mar. 1998.  