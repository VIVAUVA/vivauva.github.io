function [x,y] = movesnake(x,y,invAI,G,gamma,kappa,kappap,etashape,etasize,etaresample,fx,fy,exprad,pathY,pathlambda)
% this has a path constraint as well: only in y direction
% generates the parameters for snake first
[h,w]=size(fx);
N = length(x);
cs = cos(2*pi*(0:N-1)/N)';
sn = sin(2*pi*(0:N-1)/N)';

css = [cs(N);cs(1:N-1)];
sns = [sn(N);sn(1:N-1)];
Dx = (css-cs); Dy = (sns-sn);

ind = find(x<1);
if isempty(ind)==0, x(ind)=1;end
ind = find(y<1);
if isempty(ind)==0, y(ind)=1;end
ind = find(x>w);
if isempty(ind)==0, x(ind)=w;end
ind = find(y>h);
if isempty(ind)==0, y(ind)=h;end


vfy = interp2(fy,x,y,'*linear');
vfx = interp2(fx,x,y,'*linear');

%size(vfy)
xbar = mean(x); ybar = mean(y);
R = sqrt((x-xbar).^2 + (y-ybar).^2);
Rbar = mean(R);

% adding the pressure force
xp = [x(2:N);x(1)];    yp = [y(2:N);y(1)];
xm = [x(N);x(1:N-1)];  ym = [y(N);y(1:N-1)];

qx = xp-xm;  qy = yp-ym;
pmag = sqrt(qx.*qx+qy.*qy)+1e-5;
px = qy./pmag;     py = -qx./pmag;  % original

% shape-size
shapex = xbar + Rbar*cs;
shapey = ybar + Rbar*sn;
sizefactor = Rbar-exprad;

% path constraint
pcons = -pathlambda*(mean(y)-pathY);

x = invAI * (gamma*x + kappa*vfx + kappap.*px + etashape*shapex + etasize*sizefactor*(xbar-x)./R + etaresample*exprad*G*Dx);
y = invAI * (gamma*y + kappa*vfy + kappap.*py + etashape*shapey + etasize*sizefactor*(ybar-y)./R + etaresample*exprad*G*Dy + pcons);
