%Please cite:
%N. Ray, S. T. Acton, and K. Ley, Tracking leukocytes in vivo with shape and size 
%mac
close all; clear all; clc; 
pth='../';
D=dir(pth);
len=length(D);

for n=1:len
    if D(n).isdir==1 && ~isequal(D(n).name,'.') && ~isequal(D(n).name,'..'), % then list this directory content
        dirname = D(n).name;
        pthpth = sprintf('%s%s%s',pth,D(n).name,'/');
        DD = dir(pthpth);
        lenlen=length(DD);
        % now search this directory for .mat files
        pthpthpth = sprintf('%s%s%s',pthpth);
        gtrfiles = dir(sprintf('%s%s',pthpthpth,'*.mat'));
        for numgtr=1:length(gtrfiles)
            if ~isempty(gtrfiles) % then a ground truth file is found, track it
                TrackTrainingSequence(pthpthpth,gtrfiles(numgtr).name);
            end
        end
    end
end