function First_Untracked_Frame=comput_first_untracking_frame(thor,tvert,hor,vert)
Counter=1;
numtruth1=length(hor);
Counter=1;

First_Untracked_Frame=92;

while numtruth1>=Counter,
   X=thor(Counter);
   Y=tvert(Counter);  
Dist=(hor(Counter)-X)*(hor(Counter)-X)+(vert(Counter)-Y)*(vert(Counter)-Y);
Dist=sqrt(Dist);
         if Dist>10&&First_Untracked_Frame==92   First_Untracked_Frame=Counter; 
              return;
         end
Counter=Counter+1;
end

