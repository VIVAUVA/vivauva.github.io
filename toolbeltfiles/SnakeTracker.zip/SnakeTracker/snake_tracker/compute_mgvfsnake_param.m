function [trackX,trackY]=compute_mgvfsnake_param(pth,ext,tostart,toend,startX,startY)
% The cell radius
R = 5;

%snake parameters
alpha=0; beta = 0; gamma=0.25; kappa=2; kappap=0; shapecons=4;sizecons=4; resamplecons=10; pcons=0.2;
iterations=200; epsilon =0.005;
t = (0:0.1:2*pi)';
len=length(t);
% now set up the snake matrix, this is a one time job
[invAI,G] = snakematrix(alpha,beta,gamma,kappa,kappap,shapecons,sizecons,resamplecons,pcons,len);

X=round(startX); Y=round(startY);
% read the first frame and display it
theframeno=int2str(10000+tostart);
I = imread(sprintf('%s%s%s%s',pth,'.',theframeno(2:5),ext));
figure(1),imagesc(I),colormap(gray);
% display snake on the first frame
x = X + R*cos(t); y = Y + R*sin(t);
text(270,-5,sprintf('%s%s%s','Frame # ',int2str(1)));
figure(1),snakedisp(x,y,'g'); drawnow;

trackX=zeros(toend-tostart+1,1); trackY=zeros(toend-tostart+1,1);
trackX(1)=X; trackY(1)=Y;

% track from next frame onwards
for i=tostart+1:toend,
    
    % read a frame
    theframeno=int2str(10000+i);
    I = imread(sprintf('%s%s%s%s',pth,'.',theframeno(2:5),ext));
    
    % subimage bound
    [h,w]=size(I);
    fromx = round(max(X-3*R,1)); tox = round(min(X+3*R,w));
    fromy = round(max(Y-2*R,1)); toy = round(min(Y+2*R,h));
    
    % compute MGVF on the subimage
    [Ix,Iy]=gradient(double(I(fromy:toy,fromx:tox)));
    f = sqrt(Ix.^2+Iy.^2); % this is the edgemap
    % now call GVF to compute the edge map
    mu=0.05;
    [px,py]=GVF(f,mu,500);
    pmag = sqrt(px.*px+py.*py) + 1e-5;
    px=px./pmag; py=py./pmag;
    % compute the average y for path value, over past 10 values
    avgY = mean(trackY(max(1,i-tostart-9):i-tostart))-fromy+1;
    
    % now evolve the snake
    oldx = x-fromx+1; oldy = y-fromy+1;
    for j=1:iterations
        [x,y] = movesnake(oldx,oldy,invAI,G,gamma,kappa,kappap,shapecons,sizecons,resamplecons,px,py,R,avgY,pcons);
        if max(abs(x-oldx)+abs(x-oldx))<epsilon, break; end
        oldx = x; oldy = y;
    end
    x = x + fromx-1; y = y + fromy-1;
    X = mean(x); Y = mean(y);
    trackX(i-tostart+1)=X; trackY(i-tostart+1)=Y;
    
    % for display purpose
    figure(1),imagesc(I),colormap(gray);
    text(270,-5,sprintf('%s%s','Frame # ',int2str(i-tostart+1)));
    figure(1),hold on,plot([x(:);x(1)],[y(:);y(1)],'r'),hold off; drawnow;
end
return;