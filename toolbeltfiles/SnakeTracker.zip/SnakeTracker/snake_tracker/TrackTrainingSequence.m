function TrackTrainingSequence(pth,gtrfile)
load(sprintf('%s%s',pth,gtrfile),'hor','vert');
FirstImage = imread(sprintf('%s%s%s%s',pth,'firstimage',gtrfile(1:end-3),'bmp'));
ext = '.bmp';

i=28; % starting frame # under ..\data\
while 1
    theframeno=int2str(10000+i);
    I = imread(sprintf('%s%s%s%s',pth,gtrfile(1:6),'.',theframeno(2:5),ext));
    errorbetween=sum(sum(abs(double(I)-double(FirstImage))));
    if errorbetween<=9*255,
       break;
    end
    i=i+1;
end
[Ys Xs]=find(FirstImage~=I);
startX=Xs(5); 
startY=Ys(5); 

file = ['.',theframeno(2:5),ext];
tostart = str2num(theframeno(2:5));
toend = tostart + length(hor)-1;
seqlen = toend - tostart + 1;
% startX and startY
I=imread(sprintf('%s%s%s',pth,gtrfile(1:6),file));
figure(1),imagesc(I),colormap(gray),drawnow;
set(gcf,'doublebuffer','on');
tic
[trackX,trackY]=compute_mgvfsnake_param(sprintf('%s%s',pth,gtrfile(1:6)),ext,tostart,toend,startX,startY);
toc
% error computation
errorX = abs(trackX(1:seqlen)-hor(1:seqlen)'); 
errorY = abs(trackY(1:seqlen)-vert(1:seqlen)');
error = mean(sqrt(errorX.^2+errorY.^2));
disp(sprintf('%s%s','MS Error: ',num2str(error)));
fname = sprintf('%s%s%s%s','..\',gtrfile(1:6),'_','result');
LstTrkFrm=comput_first_untracking_frame(trackX,trackY,hor,vert);
disp(sprintf('%s%s','Last Tracked Frame #:',num2str(LstTrkFrm-1)));
save(fname,'hor','vert','trackX','trackY');