function [u,v] = GVF(f, mu, ITER)
% This is the GVF of Xu and Prince
[m,n] = size(f);
fmin  = min(f(:));
fmax  = max(f(:));
f = (f-fmin)/(fmax-fmin);  % Normalize f to the range [0,1]
f = BoundMirrorExpand(f);  % Take care of boundary condition
[fx,fy] = gradient(f);     % Calculate the gradient of the edge map
u = fx; v = fy;            % Initialize GVF to the gradient
SqrMagf = sqrt(fx.*fx + fy.*fy); % magnitude of the gradient field

% Iteratively solve for the GVF u,v
oldu=u; oldv=v; epsilon=2*(1e-5);
for i=1:ITER
    u = BoundMirrorEnsure(u);
    v = BoundMirrorEnsure(v);
    u = u + mu*del2(u) - 0.25*SqrMagf.*(u-fx);
    v = v + mu*del2(v) - 0.25*SqrMagf.*(v-fy);
    if mean2(abs(u-oldu))+mean2(abs(v-oldv))<epsilon,   break;  end
    oldu=u; oldv=v;
end
u = BoundMirrorShrink(u);
v = BoundMirrorShrink(v);