The folder contains the data and MATLAB code, which is an implementation and a 
demonstration of the Monte Carlo approach to image tracking, as presented in [1].  

Content 
I: .\data\:

  i) ves1p1.0147.bmp - ves1p1.0238.bmp: an image sequence recording leukocyte 
     movement in vivo. 
  
  ii) firstimageves1p1c1_gt.bmp: essentially the same as ves1p1.0147.bmp, the first 
     frame to be tracker, except for showing the target leukocyte to be tracked by 
     a black dot.  It is used for computation of the leukocyte statistics and for 
     initializatioin of the tracker.   

  ii) ves1p1c1_gt.mat: ground true position of the target leukocyte, determined 
     manually by a technician.  The first two ground truth positions are used for 
     tracker initialization; othwerwise, it is not used for tracking.  

II: .\mc_tracker\: 

  i) example.m: main program.  It calls other routines for tracker implementation. 
  
  ii) checkb.c: makes sure all operations are within the image boundary.  

  iii) ers_measure.c: performs local image intensity measurement.  

  iv) find_circlein.m: returns grid sample positions inside a circle of specified radius.  


To run the program, simply change the current MATLAB folder to ".\mc_tracker\" and type 
"mc_tracker" in the command window.  A figure window will pop up demonstating the 
tracking performance.  The estimated target leukocyte position is marked with a red 
asterisk ("*").  The estimated positions are saved in "mchor" and "mcvert", which can be 
used for further analysis, e.g., tracking performance analysis with the ground truth 
positions recorded in .\data\ves1p1c1_gt.mat.



[1]J. Cui, S.T. Acton, Z. Lin, A Monte Carlo approach to rolling leukocyte tracking
in vivo, Med. Image Anal. 10 (4) (2006) 598�C610.