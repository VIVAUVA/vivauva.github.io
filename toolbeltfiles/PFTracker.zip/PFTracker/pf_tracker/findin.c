#include <math.h>
#include "mex.h"

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
     
{ 
   double *z; 
    double *x,*y,*Image; 
    int m,n,m1,n1; 

    int i,j,ii,jj,j1,j2;
    
    double x2,y2,ww,x1,y1;
     
    m=mxGetM(prhs[0]);
    n=mxGetN(prhs[0]);
    m1=mxGetM(prhs[2]);
    n1=mxGetN(prhs[2]); 
    plhs[0] = mxCreateDoubleMatrix(m, n, mxREAL);
    z=mxGetPr(plhs[0]);  
    x=mxGetPr(prhs[0]);
    y=mxGetPr(prhs[1]);    
    Image=mxGetPr(prhs[2]);

    for (i=0;i<m;i++)
   {
      for (j=0;j<n;j++)
      { 
         x1=floor(x[i+j*m]); y1=floor(y[i+j*m]);
         x2=x[i+j*m]; y2=y[i+j*m];
         z[i+j*m]=0;
         for (j1=x1-1;j1<=x1+1;j1++)
         {
            for (j2=y1-1;j2<=y1+1;j2++)
            {
               if (fabs(x2-j1)<1 && fabs(y2-j2)<1)
               {
                  ww=(1-fabs(x2-j1))*(1-fabs(y2-j2));
                  z[i+j*m]=z[i+j*m]+ww*Image[(j2-1)+(j1-1)*m1];
               }
            }
         }
      }
   
   }
   
   return;
}