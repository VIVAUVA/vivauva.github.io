#include <math.h>
#include "mex.h"

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
     
{ 
    double *z,*rr; 
    double *x,*y,*r,*rc,*Image; 
    int m,n,m1,n1; 
   // double a[5];//
    double sigma=2;
    int i,j,ii,jj,j1,j2;
    double Img[51],c[51];
    double max,x2,y2,ww,x1,y1;
   
   // a[0]=1; //
   // a[1]=2; //
   // a[2]=0; //
   // a[3]=-2; //
   // a[4]=-1; //
    
    m=mxGetM(prhs[0]);
    n=mxGetN(prhs[0]);
    m1=mxGetM(prhs[4]);
    n1=mxGetN(prhs[4]);
 
    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(8, 1, mxREAL);
    z=mxGetPr(plhs[0]);
    rr=mxGetPr(plhs[1]);
    x=mxGetPr(prhs[0]);
    y=mxGetPr(prhs[1]);
    r=mxGetPr(prhs[2]);
    rc=mxGetPr(prhs[3]);
    Image=mxGetPr(prhs[4]);

    for (i=0;i<m;i++)
   {
      for (j=0;j<n;j++)
      { 
         x1=floor(x[i+j*m]); y1=floor(y[i+j*m]);
         x2=x[i+j*m]; y2=y[i+j*m];
         Img[j]=0;
         for (j1=x1-1;j1<=x1+1;j1++)
         {
            for (j2=y1-1;j2<=y1+1;j2++)
            {
               if (fabs(x2-j1)<1 && fabs(y2-j2)<1)
               {
                  ww=(1-fabs(x2-j1))*(1-fabs(y2-j2));
                  Img[j]=Img[j]+ww*Image[(j2-1)+(j1-1)*m1]; //interpolation
               }
            }
         }
      }
   
      c[0]=fabs(-2*Img[1]-Img[2]);
      c[1]=fabs(2*Img[0]-2*Img[2]-Img[3]);
      for (ii=2;ii<n-2;ii++)
      { 
         //c[ii]=0;//
         //for (jj=0;jj<5;jj++)//
         //{//
          //  if (jj+ii-2>=0 && jj+ii-2<n)//
          //  {//
          //     c[ii]=c[ii]+a[jj]*Img[jj+ii-2];//
           // }//
         //}//
         //c[ii]=fabs(c[ii]);//
         c[ii]=fabs(Img[ii-2]+2*Img[ii-1]-2*Img[ii+1]-Img[ii+2]);

      }
      c[n-2]=fabs(Img[n-4]+2*Img[n-3]-2*Img[n-1]);
      c[n-1]=fabs(Img[n-3]+2*Img[n-2]);
      max=0;
      for (ii=3;ii<n-3;ii++)
      {
         if (max<c[ii])
         {
            max=c[ii];
            rr[i]=r[ii];  // detected edge position (radial size)
         }
      }
   }
   z[0]=0;
   for (i=0;i<m;i++)
   {
      z[0]=z[0]+(rr[i]-rc[0])*(rr[i]-rc[0]);
   }
   //z[0]=exp(-z[0]/2/sigma/sigma);//
   return;
}