#include <math.h>
#include "mex.h"

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray *prhs[] )
     
{ 
    double *z1,*z2; 
    double *x,*y,*h,*w; 
    int m,n,i,j; 
          
    m=mxGetM(prhs[0]);
    n=mxGetN(prhs[0]);
    
    plhs[0] = mxCreateDoubleMatrix(m, n, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(m, n, mxREAL);
    z1=mxGetPr(plhs[0]);
    z2=mxGetPr(plhs[1]);
    x=mxGetPr(prhs[0]);
    y=mxGetPr(prhs[1]);
    h=mxGetPr(prhs[2]);
    w=mxGetPr(prhs[3]);

    for (i=0;i<m;i++)
   {
      for (j=0;j<n;j++)
      { 
        if (x[i+j*m]<1)  x[i+j*m]=1;
        if (x[i+j*m]>h[0])  x[i+j*m]=h[0];
        if (y[i+j*m]<1)  y[i+j*m]=1;
        if (y[i+j*m]>w[0])   y[i+j*m]=w[0];
        z1[i+j*m]=x[i+j*m];
        z2[i+j*m]=y[i+j*m];
      }
    }
}