%Please cite
% J. Cui, S.T. Acton, Z. Lin, A Monte Carlo approach to rolling leukocyte tracking 
% in vivo, Med. Image Anal. 10 (4) (2006) 598-610.

clear all; close all; clc;
%% initialization
path='..\data\'; % image sequence containing leukocyte to be tracked
file='ves1p1.0147.bmp'; % first image
Display = 1; % display image sequences (1) or not (0)
file_FirstImage=[path,'image',file(1:6),'c1_gt.bmp'];
file_gt=[path,file(1:6),'c1_gt.mat']; % ground truth positions
if exist(file_gt,'file')
    load(file_gt,'hor','vert');
else
    disp('file_gt does not exist');
    return;
end
% "hor, vert": ground truth positions labeled manually by a technicial
% only used for tracking performance evaluation
xcell=hor(1); ycell=vert(1);
xcell2=hor(2); ycell2=vert(2);

M=300; % #samples
randn('state',sum(100*clock)); % normally distributed pseudorandom numbers
rand('state',sum(100*clock)); % uniformly distributed pseudorandom numbers
mchor=zeros(1,91); mcvert=mchor; % estimated position
x=zeros(1,M); y=x; % sample position

theta=[0:pi/4:7/4*pi]; % \theta (radial edge detection)
r_temp=[2:0.3:8]; % radius (radial edge detection)
x_circle=(cos(theta))'*r_temp;
y_circle=(sin(theta))'*r_temp;

filestring=sprintf('%s%s',path,file); lstring=length(filestring);
numtruth=91; % in total 91 frames to be tracked
filelen = length(file);
ImageNumber = str2num(file(filelen-7:filelen-4));
theframeno=int2str(ImageNumber);
ImageNumber=ImageNumber+1;
Image=double(imread(filestring,'bmp'));
%[deltah,deltaw]=reg(filestring,20);
FrameNumber=1;
[height,width]=size(Image);

% make sure samples are inside image boundary
[yy,xx]=checkb(ycell+y_circle,xcell+x_circle,height,width);
%% obtain statistics of the target (from target in the first frame)
[z,rr]=ers_measure(xx,yy,r_temp,6,Image);
rrc=mean(rr);  % average target radius (based on edge detection)
rrd=var(rr); % variance
% find the grid inside a circle of size round(rrc)-2
[cxin,cyin]=find_circlein(0,0,round(rrc)-2);
cxin=cxin(2:end); cyin=cyin(2:end);
[rry,rrx]=checkb(ycell+cyin,xcell+cxin,height,width);
ccv=findin(rrx,rry,Image);
ccv1=std(ccv(:));

if rrc<=6
    sigma_d=1.5;
else
    sigma_d=2;
end

%% tracking algorithm
wehaveanimage=1;
while wehaveanimage && (FrameNumber<=numtruth)
    if FrameNumber==1
        for m=1:M
            theta=rand*2*pi; d=randn*sigma_d;
            x(m)=xcell+d*cos(theta); y(m)=ycell+d*sin(theta); % generate samples
            [yy,xx]=checkb(y(m)+y_circle,x(m)+x_circle,height,width);
            [z,rr]=ers_measure(xx,yy,r_temp,rrc,Image);
            z=exp(-(z-rrd*8)^2/2/36);
            [rry,rrx]=checkb(y(m)+cyin,x(m)+cxin,height,width);
            v=findin(rrx,rry,Image);
            v1=std(v(:));
            vv=exp(-(v1-ccv1)^2/2/25);
            weight(m)=z*vv; % sample weighting
        end
        weight=weight./sum(weight); % normalization
        mchor(1)=weight*x'; mcvert(1)=weight*y'; % estimated position
        cxx(1)=mchor(1); cyy(1)=mcvert(1);
    end
    if FrameNumber==2
        for m=1:M
            theta=rand*2*pi; d=randn*sigma_d;
            x(m)=xcell2+d*cos(theta); y(m)=ycell2+d*sin(theta);
            [yy,xx]=checkb(y(m)+y_circle,x(m)+x_circle,height,width);
            [z,rr]=ers_measure(xx,yy,r_temp,rrc,Image);
            z=exp(-(z-rrd*8)^2/2/36);
            [rry,rrx]=checkb(y(m)+cyin,x(m)+cxin,height,width);
            v=findin(rrx,rry,Image);
            v1=std(v(:));
            vv=exp(-(v1-ccv1)^2/2/25);
            weight(m)=z*vv;
        end
        weight=weight./sum(weight);
        mchor(2)=weight*x';
        mcvert(2)=weight*y';
    end
    
    if FrameNumber>2
        i=FrameNumber;
        cxx(i-1)=mchor(i-1); cyy(i-1)=mcvert(i-1);
        if i>4 % position prediction based on previous position estimation
            cx_temp=cxx(i-1)+(cxx(i-1)-cxx(i-2))/3+(cxx(i-2)-cxx(i-3))/3+(cxx(i-3)-cxx(i-4))/3;
        elseif i>3
            cx_temp=cxx(i-1)+(cxx(i-1)-cxx(i-2))*3/5+(cxx(i-2)-cxx(i-3))*2/5;
        else
            cx_temp=cxx(i-1)+(cxx(i-1)-cxx(i-2));
        end
        cy_temp=cyy(i-1);
        
        for m=1:M
            theta=rand*2*pi; d=randn*sigma_d;
            x(m)=cx_temp+d*cos(theta); y(m)=cy_temp+d*sin(theta);
            [yy,xx]=checkb(y(m)+y_circle,x(m)+x_circle,height,width);
            [z,rr]=ers_measure(xx,yy,r_temp,rrc,Image);
            z=exp(-(z-rrd*8)^2/2/36);
            [rry,rrx]=checkb(y(m)+cyin,x(m)+cxin,height,width);
            v=findin(rrx,rry,Image);
            v1=std(v(:));
            vv=exp(-(v1-ccv1)^2/2/25);
            weight(m)=z*vv;
        end
        ss=sum(weight);
        if ss==0 ss=1; end
        weight=weight./ss;
        mchor(i)=weight*x'; mcvert(i)=weight*y';
    end
    if Display
        theframeno=int2str(ImageNumber);
        filestring(lstring-6:lstring-4)=theframeno;
        fid=fopen(filestring);
        Image=imread(filestring,'bmp');
        figure(1),imagesc(Image),colormap(gray); axis off;
        hold on, plot(mchor(FrameNumber),mcvert(FrameNumber),'r*'),
        text(300,-5,sprintf('%d',FrameNumber));
        hold off;
        drawnow;
    end
    theframeno=int2str(ImageNumber);
    ImageNumber=ImageNumber+1;
    filestring(lstring-6:lstring-4)=theframeno;
    fid=fopen(filestring);
    if fid>=0
        fclose(fid);
        Image=double(imread(filestring,'bmp'));
        FrameNumber=FrameNumber+1;
    else
        wehaveanimage=0;
        break;
    end
end
mchor=mchor(1:FrameNumber-1);
mcvert=mcvert(1:FrameNumber-1);