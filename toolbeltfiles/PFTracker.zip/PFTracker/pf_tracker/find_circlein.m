function [cir_inx,cir_iny]=find_circlein(x,y,r)

cir_inx=0;
cir_iny=0;

for j=y-r:y+r
   for i=x-r:x+r
      if sqrt((x-i)^2+(y-j)^2)<=r
         cir_inx=[cir_inx,i];
         cir_iny=[cir_iny,j];
      end
   end
end
